<html>
 <head>
  <title>Login</title>
 </head>
 <body>
 	<h1>Login</h1>
 	<p>~~~~~~~~~~~~~~</p>
 	<?php
 		ini_set('display_errors', 'On');
 		$username = $_POST["username"];
 		$password = $_POST["password"];

	 	echo "<p>And now some php</p>";
	 	echo "<p>Username: ". $username . "</p>";
	 	echo "<p>Pasword: ". $password . "</p>";
	 	echo "<p>Verifying your user information...</p>";
	 	$db = new PDO('mysql:host=localhost;dbname=oblog;charset=utf8', 'root', '');
	 	$result = $db->query("SELECT password FROM users WHERE username='$username'");

	 	$db_password = $result->fetch()[0];
		
		if ($db_password == $password) {
			echo "<p>Welcome, $username.</p>";
			session_start();
			$_SESSION["username"] = $username;
		}
		else {
			echo "<p>Sorry, your login information failed to authenticate.</p>";
		}
	?>
</body>

</html>
