<html>
 <head>
  <title>New Post</title>
 </head>
 <body>
 	<h1>New Post</h1>
 	<p>~~~~~~~~~~~~~~</p>
 	<?php
 		ini_set('display_errors', 'On');
 		$subject = $_POST["subject"];
 		$body = $_POST["body"];

	 	echo "<p>And now some php</p>";
	 	echo "<p>Subject: ". $subject . "</p>";
	 	echo "<p>Body: ". $body . "</p>";
	 	echo "<p>Opening database...</p>";
	 	$db = new PDO('mysql:host=localhost;dbname=oblog;charset=utf8', 'root', '');

	 	$db->query("insert into posts (title, body, created) values ('$subject', '$body', NOW());");

	 	echo "<p>Created new post successfully!</p>";
	?>
</body>

</html>
