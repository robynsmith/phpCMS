<html>
 <head>
  <link rel="stylesheet" type="text/css" href="oblog_styles.css">
  <title>View Posts</title>
 </head>
 <body>
 	<h1>Posts</h1>
 	<p>~~~~~~~~~~~~~~</p>
 	<?php
 		ini_set('display_errors', 'On');
	 	echo "<p>And now some php</p>";
	 	echo "<p>Here is where we do the db connection:</p>";
	 	$db = new PDO('mysql:host=localhost;dbname=oblog;charset=utf8', 'root', '');
	 	echo "<p>And now for some posts:</p>";
	 	foreach($db->query('SELECT * FROM posts') as $row) {
    		echo '<div class="blog_post"><h2>'. $row['title'].'</h2><p>'.$row['body'].'</p></div>';
		}
	?>
</body>

</html>