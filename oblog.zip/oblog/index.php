<html>
 <head>
  <title>PHP Test</title>
 </head>
 <body>
 	<p>Hello World</p>';
	<form action="action.php" method="post">
	<p>Your name: <input type="text" name="name" /></p>
	<p>Your age: <input type="text" name="age" /></p>
	<p><input type="submit" /></p>
</form>

</body>

</html>