<html>
<head>
  <title>Applying Edit</title>
 </head>
<body>
	<h1>Applying Edit</h1>
	<p>~~~~~~~~~~~~~~~</p>
	<?php
 		ini_set('display_errors', 'On');
 		//var_dump($_POST);
 		$subject = $_POST['subject'];
 		$body = $_POST['body'];
 		$id = $_POST['id'];
	 	//echo "<p>And now some php</p>";
	 	$db = new PDO('mysql:host=localhost;dbname=oblog;charset=utf8', 'root', '');
	 	//echo "<p>This is the query that will be used for the update: UPDATE posts SET title='$subject', body='$body' WHERE id='$id';</p>";
	 	$db->query("UPDATE posts SET title='$subject', body='$body', modified=now() WHERE id='$id';");
	 	//echo "<p>Update Complete!</p>"
	 	header("Location: http://127.0.0.1/oblog/view_posts.php");
	?>
</body>
</html>