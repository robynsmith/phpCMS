<html>
<head>
  <title>Editing Post</title>
 </head>
<body>
	<h1>Editing Post</h1>
	<p>~~~~~~~~~~~~~~~</p>
	<?php
 		ini_set('display_errors', 'On');
 		var_dump($_POST);
 		$item = $_POST['name'];
	 	echo "<p>And now some php</p>";
	 	echo "<p>$item</p>";
	 	$db = new PDO('mysql:host=localhost;dbname=oblog;charset=utf8', 'root', '');

	 	echo "<p>This is the query that will be used for the EDIT: SELECT * FROM posts WHERE ID=$item;</p>";
	 	$q = "SELECT * FROM posts WHERE id=$item;";
	 	$result = $db->query($q)->fetch();
	 	
	 	$subject = $result['title'];
	 	$body = $result['body'];
	 	$id = $result['id'];
	 	//echo $result['title'] . ' ' . $result['body'];
	?> 
	<h3>Edit Post</h3>
    <form action="edit_post_action.php" method="post">
    	<input type="hidden" name="id" value="<?php echo $id;?>">
    	Subject: <input type="text" name="subject" value="<?php echo $subject;?>"><br>
		Body: <input type="text" name="body" value="<?php echo $body;?>"><br>
    	<input type="submit" name="submit" value="Finished">
	</form> 
</body>
</html>