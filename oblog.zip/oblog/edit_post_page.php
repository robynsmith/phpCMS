<html>
<head>
  <title>Edit Posts</title>
 </head>
<body>
	<h1>Edit Posts Page</h1>
	<p>~~~~~~~~~~~~~~~</p>
	<?php
 		ini_set('display_errors', 'On');
	 	echo "<p>And now some php</p>";
	 	echo "<p>Here is where we do the db connection:</p>";
	 	$db = new PDO('mysql:host=localhost;dbname=oblog;charset=utf8', 'root', '');
	 	echo "And now for some posts:<br>";
	 	foreach($db->query('SELECT * FROM posts') as $row) {
    		echo '<h2>'. $row['title'].'</h2><p>'.$row['body'].'</p><br>';
    		?>
    		<form action="editing_post.php" method="post">
    			<input type="hidden" name="name" value="<?php echo $row['id']; ?>">
				<input type="submit" name="submit" value="Edit">
			</form>
	<?php

			}
	?>
	
</body>
</html>