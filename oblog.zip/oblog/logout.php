<html>
 <head>
  <title>Logout</title>
 </head>
 <body>
 	<h1>Logout</h1>
 	<p>~~~~~~~~~~~~~~</p>
 	<?php
 		session_start();
 		session_unset(); 
 		session_destroy();
 		echo "<p>Successfully logged out.</p>"
	?>
</body>

</html>
