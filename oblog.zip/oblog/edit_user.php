<html>
<head>
  <title>Change User Details</title>
 </head>
<body>
	<h1>Changing User Details</h1>
	<p>~~~~~~~~~~~~~~~</p>
	<?php
 		ini_set('display_errors', 'On');
 		var_dump($_POST);
 		$item = $_POST['password'];
 		$username = 'rob';
	 	echo "<p>And now some php</p>";
	 	echo "<p>$item</p>";
	 	$db = new PDO('mysql:host=localhost;dbname=oblog;charset=utf8', 'root', '');
	 	echo "<p>This is the query that will be used for the update: UPDATE users SET password='$item' WHERE username='$username';</p>";
	 	$db->query("UPDATE users SET password='$item' WHERE username='$username';");
	 	echo "<p>Update Complete!</p>";
	 	
	?>
</body>
</html>