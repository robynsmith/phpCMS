<html>
<head>
  <title>Deleting Post</title>
 </head>
<body>
	<h1>Deleting Post</h1>
	<p>~~~~~~~~~~~~~~~</p>
	<?php
 		ini_set('display_errors', 'On');
 		var_dump($_POST);
 		$item = $_POST['name'];
	 	echo "<p>And now some php</p>";
	 	echo "<p>$item</p>";
	 	$db = new PDO('mysql:host=localhost;dbname=oblog;charset=utf8', 'root', '');
	 	echo "<p>This is the query that will be used for the delete: DELETE FROM posts WHERE ID=$item</p>";
	 	$db->query("DELETE FROM posts WHERE ID=$item");
	 	echo "<p>Deletion Complete!</p>";
	 	
	?>
</body>
</html>